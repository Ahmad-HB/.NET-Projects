create definer = root@localhost view VwUsers as
select `freebooks`.`aspnetusers`.`Id`         AS `Id`,
       `freebooks`.`aspnetusers`.`Name`       AS `Name`,
       `freebooks`.`aspnetusers`.`ImageUser`  AS `ImageUser`,
       `freebooks`.`aspnetusers`.`ActiveUser` AS `ActiveUser`,
       `freebooks`.`aspnetusers`.`Email`      AS `Email`,
       `freebooks`.`aspnetroles`.`Name`       AS `Role`
from ((`freebooks`.`aspnetusers` join `freebooks`.`aspnetuserroles`
       on ((`freebooks`.`aspnetusers`.`Id` = `freebooks`.`aspnetuserroles`.`UserId`))) join `freebooks`.`aspnetroles`
      on ((`freebooks`.`aspnetuserroles`.`RoleId` = `freebooks`.`aspnetroles`.`Id`)));

